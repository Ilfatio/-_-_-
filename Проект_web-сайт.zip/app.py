from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import random

# Создание приложения
app = Flask(__name__)

# Создание базы данных для хранения статье(отзывов)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///blog.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
app.app_context().push()

# Создание модели базы данных


class Article(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    intro = db.Column(db.String(300), nullable=False)
    text = db.Column(db.Text, nullable=False)
    date = db.Column(db.DateTime, default=datetime.now)

    def __repr__(self):
        return '<Article %r>' % self.id

# Создание главной страницы сайта


@app.route('/')
@app.route('/home')
def index():
    return render_template('index.html')

# Создание страницы о сайте


@app.route('/about')
def about():
    return render_template('about.html')

# Создание страницы для оформления "Бюджетного" тарифа


@app.route('/buy/1')
def buy_1():
    name = "Бюджетный"
    price = 280
    numbers = random.randint(1, 99999)
    return render_template('buy.html', name=name, price=price, numbers=numbers)

# Создание страницы для оформления "Стандарт" тарифа


@app.route('/buy/2')
def buy_2():
    name = "Стандарт"
    price = 415
    numbers = random.randint(1, 99999)
    return render_template('buy.html', name=name, price=price, numbers=numbers)

# Создание страницы для оформления "Премиум" тарифа


@app.route('/buy/3')
def buy_3():
    name = "Премиум"
    price = 950
    numbers = random.randint(1, 99999)
    return render_template('buy.html', name=name, price=price, numbers=numbers)

# Создание страницы для отображения всех статей


@app.route('/posts')
def posts():
    articles = Article.query.order_by(Article.date.desc()).all()
    return render_template('posts.html', articles=articles)

# Страница для детального просмотра статьи


@app.route('/posts/<int:id>')
def posts_detail(id):
    article = Article.query.get(id)
    return render_template('posts_detail.html', article=article)

# Страница для удаления статьи


@app.route('/posts/<int:id>/delete')
def posts_delete(id):
    article = Article.query.get_or_404(id)

    try:
        db.session.delete(article)
        db.session.commit()
        return redirect('/posts')
    except:
        return 'При удалении статьи произошла ошибка'

# Страница для редактирования статьи


@app.route('/posts/<int:id>/update', methods=['POST', 'GET'])
def post_update(id):
    article = Article.query.get(id)
    if request.method == 'POST':
        article.title = request.form['title']
        article.intro = request.form['intro']
        article.text = request.form['text']

        try:
            db.session.commit()
            return redirect('/posts')
        except:
            return 'При редактировании статьи произошла ошибка'
    else:
        return render_template('post_update.html', article=article)

# Страница для создания статьи


@app.route('/create-article', methods=['POST', 'GET'])
def create_article():
    if request.method == 'POST':
        title = request.form['title']
        intro = request.form['intro']
        text = request.form['text']

        article = Article(title=title, intro=intro, text=text)

        try:
            db.session.add(article)
            db.session.commit()
            return redirect('/posts')
        except:
            return 'При добавлении статьи произошла ошибка'
    else:
        return render_template('create-article.html')

# Запуск всего сайта и проверка всех его ошибок


if __name__ == '__main__':
    app.run(debug=True)
